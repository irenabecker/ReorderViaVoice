'use strict';
 
const {dialogflow,Permission,SimpleResponse, Suggestions,BasicCard,Image,BrowseCarousel,BrowseCarouselItem, Carousel,CarouselItem,NewSurface} = require('actions-on-google');
const functions = require('firebase-functions');
const app = dialogflow({debug: true});
const https = require('https');
const picBags = "http://picscdn.redblue.de/doi/pixelboxx-mss-66234900/fee_325_225_png/MIELE-SB-SET-GN-CareBox-3D--16-Staubbeutel--4-Motorschutz--und-4-Abluftfilter--Kunststoffbox";
const picFood = "http://pedigree.co.za/wp-content/uploads/2017/12/list1.png";
const picInk = "https://media.hpshopping.in/catalog/product/cache/c687aa7517cf01e65c009f6943c2b1e9/6/8/680.png";
 
var favorites = [" vacuum bags", " dog food", " printer cartridge"];
  
app.intent('Default Welcome Intent', (conv) => {
    conv.ask(new SimpleResponse({
        speech: "Welcome at Reorders, Emma!  \nFollowing products have been saved in your account:" + favorites + ".  \nWhich one would you like to reorder?",
        text : "Please choose one of these products:"
    }));

    if (!conv.surface.capabilities.has('actions.capability.SCREEN_OUTPUT')) {
        conv.ask('Sorry, try this on a screen device or select the phone surface in the simulator.');
        return;
    }

    conv.ask(new BrowseCarousel({

        items: [
            new BrowseCarouselItem({
                title: 'Vacuum Bags',
                url: "https://google.com",
                description: 'Price incl. VAT: 15.98 €',
                image: new Image({
                    url: picBags,
                    alt: "Vacuum bags"
                })
            }),
            new BrowseCarouselItem({
                title: 'Dog Food',
                url: "https://google.com",
                description: 'Price incl. VAT: 18.57 €',
                image: new Image({
                    url: picFood,
                    alt: "Dog food"
                })
            }),
            new BrowseCarouselItem({
                title: "Printer Cartridge",
                url: "https://google.com",
                description: 'Price incl. VAT: 7.98 €',
                image: new Image({
                    url: picInk,
                    alt: "Toner Cartridge"
                })
          }),
        ]
    }));
 
 });

app.intent('Default Fallback Intent', (conv) => {
    conv.ask("Ups, sorry. Something went wrong.");
 });
 
app.intent('Reordering', (conv, {favorites}) => {
    var productDescription;
    var title;
    var text;
    var imageUrl;
    var imageAlt;
    if (favorites =="vacuum bags"){
        productDescription = "Miele AirClean, Type S. 4 Bags and 2 Filters for 15.98 €. ";
        title = "Miele Vacuum Bags";
        text = "**Price incl. 19% tax: 15.98€**  \n - Includes: 4 Bags and 2 Filters  \n  - Captures 99.9% of all dust particles  \n - Permeable construction allows optimal airflow at high suction settings to save energy  \n - Made with tear resistant material  \n - Compatible with Miele Compact models";
        imageUrl = picBags,
        imageAlt = "Vacuum bags";
    } else if(favorites =="dog food"){
        productDescription = "Pedigree Adult Wet Dog Food, chicken and vegetables. 12 Kilo bag for 18.57 €. ";
        title = "Pedigree Adult Wet Dog Food";
        text = "**Price incl. 19% tax: 18.57€**  \n - Volume: 12 KG bag  \n - For dogs of all sizes  \n - Only chicken and vegetables  \n - No fillers, corn, artificial flavors or preservatives";
        imageUrl = picFood,
        imageAlt = "Dog food";
    } else if(favorites =="printer cartridge"){
        productDescription = "Black HP Original Toner Cartridge for 7.98 €. ";
        title = "Black HP Toner Cartridge";
        text = "**Price incl. 19% tax: 7.98€**  \n - Includes: 3 ink cartridges  \n - Black yields up to 2,000 pages  \n - Storage temperature range: -40 - 60° C  \n - Officejet Pro 8000 series";
        imageUrl = picInk;
        imageAlt = "Toner Cartridge";
    } else{"I don't know which product you want to order! Please try again. Say vacuum bag, dog food or printer cartridge."}

    conv.ask(new SimpleResponse({
        speech: productDescription + "  \nDo you want to order this product now?",
        text : "You choose:"
        }));
    conv.ask(new BasicCard({
        text: text,
        title: title,
        image: new Image({
            url: imageUrl,
            alt: imageAlt
        })
    }));
   
    conv.ask(new Suggestions("Yes", "No"));
 });


app.intent('Confirmation', (conv, {confirmation}) =>{
    if (confirmation == "Yes"){
        conv.ask(new SimpleResponse({
            speech: "The order was successfull, Emma. You will get a confirmation mail in a few minutes. Thank you and good bye.",
            text : "The confirmationmal has been send."
        }));
        conv.close(new BasicCard({
            text:"Your confimation was sent to emma@reorders.com",
            title:"Thank you, Emma!",
            image: new Image({
                url: "https://www.afghomeloans.com.au/wp-content/uploads/2018/01/afg-hl-icon_circletick-174-1024x1024.png",
                alt: "Success"
            })
        }));
        
    } else {
        conv.close("All right, the order has been cancelled. We look forward to your next visit!");
    }
}); 
 
exports.dialogflowFirebaseFulfillment = functions.https.onRequest(app);